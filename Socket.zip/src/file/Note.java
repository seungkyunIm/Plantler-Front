package file;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

public class Note {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		String txt = scanner.nextLine();
		out(txt);
		

	// in();
}

public static void in() { // 대상 파일의 내용을 읽어 오는 메소드
try {
//FileInputStream fis = new FileInputStream("src/text.txt");
//InputStreamReader isr = new InputStreamReader(fis);
//BufferedReader br = new BufferedReader(isr);

BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream("src/text.txt")));
	int value = 0;
	while((value = in.read()) != -1) {
	System.out.print( (char) value );
	
	}
	in.close();
	} catch (FileNotFoundException e) {
	e.printStackTrace();
	} catch (IOException e) {
	e.printStackTrace();
	}

}

public static void out(String txt) { // 대상 파일에 내용을 입력 하는 메소드
System.out.println("입력 될 내용 : " + txt);
try {
//FileOutputStream fos = new FileOutputStream("src/text.txt", false);
//OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
//BufferedWriter bw = new BufferedWriter(osw);
	BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("src/text.txt", true), "UTF-8"));
	out.write(txt);
	out.write("\n");
	out.close();
	} catch (UnsupportedEncodingException e) {
	e.printStackTrace();
	} catch (FileNotFoundException e) {
	e.printStackTrace();
	} catch (IOException e) {
	e.printStackTrace();
}
}

}