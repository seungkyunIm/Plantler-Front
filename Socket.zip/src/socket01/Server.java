package socket01;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.Buffer;

public class Server {

	public static void main(String[] args) {
		// 소켓 통신 서버용으로 무조건 켜져있어야 사용자가 사용 가능 
		try {
			ServerSocket serverSocket = new ServerSocket(9000);
			System.out.println("소켓 서버 실행 완료!");
			
			while(true) {
				// 소켓 서버 접속 허용 처리
				Socket socket = serverSocket.accept();

				
				BufferedReader in =  new BufferedReader(new InputStreamReader(socket.getInputStream()));
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			
				System.out.println("클라이언트 접속 되었습니다.");
				
				String msg = in.readLine();
				System.out.println("클라이언트 대화글 :" + msg);
				
				out.println("서버에 전송 받은 글:" + msg);
				
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

/*
 * 				// 입력
//				InputStream is =socket.getInputStream(); // 클라이언트에서 오는 요청
//				InputStreamReader isr = new InputStreamReader(is);
//				BufferedReader br = new BufferedReader(isr);
			
				// 출력
//				OutputStream os = socket.getOutputStream();
//				PrintWriter pw = new PrintWriter(os, true);
 * */
